from django.shortcuts import render, redirect
from django.http import HttpResponse
from.models import Reservas
from.form import Reservacion

# Create your views here.
def inicio(request):
    return render(request, 'reservas/inicio.html')

def nosotros(request):
    return render(request, 'reservas/nosotros.html')

def reservacion(request):
    reservacion = reservacion.object.all()
    return render(request, 'reservacion/index.html', {'reservacion': reservacion})

def agregar_reserva(request):
    formulario = Reservacion(request.POST or None)
    if formulario.is_valid():
        formulario.save()
        return redirect('reservacion')
    return render(request, 'reservacion/agregar.html',{'formulario': formulario})

def modificar(request, id):
    reservacion = reservacion.objects.get(id=id)
    formulario = reservacion(request.POST or None, request.FILES or None, instance=reservacion)
    if formulario.is_valid() and request.POST:
        formulario.save()
        return redirect('reservacion')
    return render(request, 'reservacion/modificar.html', {'formulario': formulario})

def eliminar(request, id):
    reservacion = reservacion.objects.get(id=id)
    reservacion.delete()
    return redirect('reservacion')

