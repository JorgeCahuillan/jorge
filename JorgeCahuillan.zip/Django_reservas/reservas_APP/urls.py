from django.urls import path
from.import views

urlpatterns = [
    path('', views.inicio, name='inicio'),
    path('nosotros', views.nosotros, name='nosotros'),
    path('reservas', views.reservas, name='reservas'),
    path('reservacion/agregar', views.agregar_reserva, name='agregar'),
    path('reservacion/modificar/<int:id>', views.modificar, name='modificar'),
    path('eliminar/<int:id>', views.eliminar, name='eliminar'),
]