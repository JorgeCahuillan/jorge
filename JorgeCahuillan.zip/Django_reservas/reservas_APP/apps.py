from django.apps import AppConfig


class ReservasAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'reservas_APP'
