from django import forms
from.models import Reservacion

class Reservacion(forms.ModelForm):
    class Meta:
        model = Reservacion
        fields = '__all__'