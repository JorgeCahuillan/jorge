from django.db import models

# Create your models here.

class Reservas(models.Model):
    id = models.AutoField()
    nombre = models.CharField(max_length=50)
    fecha_reserva = models.DateField(max_length=10)
    telefono = models.CharField(max_length=20)
    hora = models.DateTimeField(max_length=6)
    cantidad_personas = models.CharField(max_length=15)
    estado = models.CharField(max_length=5)
    observacion = models.TextField(max_length=200)
